#########################################################
# Outshine Solutions                                    #
# http://outshinesolutions.com/                         #
# Author: Amitesh php team Omega @ Outshinesolutions    #
# Displays Time and Date with your customized Messages  #
# User can choose multiple formats                      #
#########################################################

Ultimate Php Date Script
-----------

This is ultimate date script which can help you to
insert date and time in any of your php scripts with 
inbuilt 12 formats which ca easily be scaled up. 

Options to add custom messgaes have been implemented 
for more customization.


Current version: 1.0

Requires: PHP4+

Instructions:

Just upload the file includetime.inc.php to your webspace
and include the script via PHP in your sourcecode like this:

<?php include('includetime.inc.php'); ?>

Thank you for downloading this script

--

This script is free software, licenced under GPL
http://www.gnu.org/copyleft/gpl.html
