<?php
  //Be sure to include this line
  include('includetime.inc.php');
  // Below is just exemplary dummy HTML code
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Ultimate Date Php Script - Outshine Solutions</title>
</head>
<body>
<h1>Ultimate Php Date Script By Outshine Solutions</h1>
<br />
<br />
Example Follows
<hr>
<strong><?php echo $message; ?></strong>, <?php echo $date; ?>

<br />
<br />
<br />
~~~~~~~~~~~~~~~~
<br />
About Outshine Solutions:
<br />
<a href="http://outshinesolutions.com">Outshine Solutions</a> is a software development company providing <a href="http://outshinesolutions.com/development/">Application Development</a>, <a href="http://outshinesolutions.com/seo-services/">SEO Services</a>, <a href="http://outshinesolutions.com/website-design/">Website design</a> and <a href="http://outshinesolutions.com/web-hosting/">Web Hosting Services</a>. Support for this script is provided through <a href="http://forums.outshinesolutions.com">Outshine Solutions Forums</a>. :)
</body>
</html>
